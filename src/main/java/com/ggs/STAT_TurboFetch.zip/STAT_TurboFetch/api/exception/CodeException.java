package com.ggs.STAT_TurboFetch.api.exception;

public class CodeException extends RuntimeException{
    public CodeException(String message) { super(message); }
}
