package com.ggs.STAT_TurboFetch;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class StatTurboFetchApplication {

	public static void main(String[] args) {
		SpringApplication.run(StatTurboFetchApplication.class, args);
	}

}
