package com.ggs.STAT_TurboFetch.client;

import java.util.List;

public interface FtClient {
    List<String> getAllUsers(String code);
}
